const Server = require("../models/Server");

const HEARTBEAT_TIMEOUT_MS = 60000; // 60 seconds

/**
 * Selects the best deployment server based on collected metrics.
 * 
 * Filters out:
 *  - OFFLINE servers
 *  - Servers with lastHeartbeat older than 60 seconds
 *  - Servers whose activeDeployments >= maxDeployments
 * 
 * Sorts remaining candidate servers by:
 *  1. Lowest activeDeployments
 *  2. Lowest cpuUsage
 *  3. Lowest ramUsage
 *  4. Lowest diskUsage
 * 
 * Throws an Error if no eligible server is found.
 */
async function getDeploymentServer() {
  const servers = await Server.find({ status: { $ne: "OFFLINE" } });
  const now = Date.now();

  const candidates = servers.filter((server) => {
    // 1. Must not be OFFLINE
    if (server.status === "OFFLINE") {
      return false;
    }

    // 2. Must have a fresh heartbeat within the last 60 seconds
    if (!server.lastHeartbeat) {
      return false;
    }
    const heartbeatAge = now - new Date(server.lastHeartbeat).getTime();
    if (heartbeatAge > HEARTBEAT_TIMEOUT_MS) {
      return false;
    }

    // 3. Must have available capacity (activeDeployments < maxDeployments)
    const maxCapacity = server.maxDeployments !== undefined ? server.maxDeployments : 10;
    const currentActive = server.activeDeployments || 0;
    if (currentActive >= maxCapacity) {
      return false;
    }

    return true;
  });

  if (candidates.length === 0) {
    throw new Error("No healthy deployment server available");
  }

  // Sort candidates according to multi-tier priority
  candidates.sort((a, b) => {
    // Priority 1: lowest activeDeployments
    const activeA = a.activeDeployments || 0;
    const activeB = b.activeDeployments || 0;
    if (activeA !== activeB) return activeA - activeB;

    // Priority 2: lowest cpuUsage
    const cpuA = a.cpuUsage || 0;
    const cpuB = b.cpuUsage || 0;
    if (cpuA !== cpuB) return cpuA - cpuB;

    // Priority 3: lowest ramUsage
    const ramA = a.ramUsage || 0;
    const ramB = b.ramUsage || 0;
    if (ramA !== ramB) return ramA - ramB;

    // Priority 4: lowest diskUsage
    const diskA = a.diskUsage || 0;
    const diskB = b.diskUsage || 0;
    return diskA - diskB;
  });

  return candidates[0];
}

module.exports = {
  getDeploymentServer,
};
