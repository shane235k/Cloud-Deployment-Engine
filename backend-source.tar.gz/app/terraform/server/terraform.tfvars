key_name      = "p377-key"
aws_region    = "us-east-2"
instance_type = "t3.micro"
instance_name = "kubedeploy-server"
