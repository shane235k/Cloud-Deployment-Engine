variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-2"
}

variable "sg_name" {
  description = "Name for the shared KubeDeploy Security Group"
  type        = string
  default     = "kubedeploy-sg"
}
